var Auth = (function () {
  var KUNCI = 'qasirUser';

  var AKUN = [
    { username: 'kasir',   password: 'kasir123',   role: 'kasir',   nama: 'AbibSharimThesa', label: 'Kasir/Admin' },
    { username: 'pemilik', password: 'pemilik123', role: 'pemilik', nama: 'AbibSharimThesa', label: 'Pemilik' }
  ];


  var HALAMAN_AWAL = { kasir: 'dashboard.html', pemilik: 'owner_dashboard.html' };


  function cekLogin(username, password, role) {
    for (var i = 0; i < AKUN.length; i++) {
      var a = AKUN[i];
      if (a.username === username && a.password === password && a.role === role) return a;
    }
    return null;
  }

  function simpanSesi(akun) {
    sessionStorage.setItem(KUNCI, JSON.stringify({
      username: akun.username, role: akun.role, nama: akun.nama, label: akun.label
    }));
  }

  function ambilSesi() {
    try { return JSON.parse(sessionStorage.getItem(KUNCI)); } catch (e) { return null; }
  }

  function keluar() { sessionStorage.removeItem(KUNCI); }


  function wajibPeran(roleHalaman) {
    var sesi = ambilSesi();
    if (!sesi) { window.location.replace('login.html'); return; }
    if (sesi.role !== roleHalaman) {
      window.location.replace(HALAMAN_AWAL[sesi.role] || 'login.html');
    }
  }

  
  document.addEventListener('DOMContentLoaded', function () {
    var sesi = ambilSesi();
    var nama = document.getElementById('userNameDisplay');
    var peran = document.getElementById('userRoleDisplay');
    if (sesi && nama) nama.textContent = sesi.nama;
    if (sesi && peran) peran.textContent = sesi.label;

    var tombolKeluar = document.querySelectorAll('.dropdown-item[href="login.html"]');
    for (var i = 0; i < tombolKeluar.length; i++) {
      tombolKeluar[i].addEventListener('click', keluar);
    }
  });

  return {
    cekLogin: cekLogin, simpanSesi: simpanSesi, ambilSesi: ambilSesi,
    keluar: keluar, wajibPeran: wajibPeran, halamanAwal: HALAMAN_AWAL
  };
})();
